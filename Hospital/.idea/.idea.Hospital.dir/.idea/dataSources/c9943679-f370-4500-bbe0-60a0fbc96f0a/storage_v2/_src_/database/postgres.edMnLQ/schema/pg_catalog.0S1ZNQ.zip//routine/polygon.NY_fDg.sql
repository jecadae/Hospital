create function polygon(circle) returns polygon
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function polygon(circle, circle) is 'convert vertex count and circle to polygon';

alter function polygon(circle, circle) owner to postgres;

